/// @ref core
/// @file glm/vec2.hpp

#include "detail/setup.hpp"

#pragma once

#include "detail/type_vec2.hpp"
